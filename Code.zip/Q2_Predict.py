# -*- coding: utf-8 -*-
"""
Created on Sun Jan 27 16:38:39 2019

@author: LiYuexiang
"""

import pandas as pd 
import numpy as np
import statsmodels.api as sm

#The county used to analysis   Note:if you want to analysis other county, you need change it
id = '0500000US51041'
id2 = '51041'

#Read data of the collection of county's socio-economic data
data = pd.read_excel('F:/AI/DDD/socio_ecoData_%s.xlsx'%id2)
#Get the item id
cols = data.columns

#The predicted value
insert_data = list([])
for c in cols:
    #Get each item's data
    dta = np.array(data[c], dtype=np.float)
    df = pd.Series(dta)
    #Data series
    date = pd.date_range('2010', periods=7, freq='A')
    df.index = date
    #Use ARMA(1,0,1) to predict the value of 2017
    arma_mod =  sm.tsa.ARMA(df,(1,0,1)).fit()
    pre = arma_mod.predict('2017', '2017', dynamic=True)
    #Set error
    error = 0.1
    #Judge whether predicted value is in the valid range
    if pre['2017-12-31'] < df['2016-12-31']*(1-error) or pre['2017-12-31'] > df['2016-12-31']*(1+error):
        sum_ = 0
        sum_ = df['2013-12-31'] + df['2014-12-31'] + df['2015-12-31'] + df['2016-12-31']
        avg = sum_/4
        value = int(avg)
    else:
        value = int(pre['2017-12-31'])
    #Collect predicted value
    insert_data.append(value)
#change them to Series
insert_data = pd.Series(insert_data, cols)
#Store them with previous value
for c in cols:
    data.loc[2017,c] = insert_data[c]
#Store into excel
data.to_excel('F:/AI/DDD/socio_ecoData_%s(predicted).xlsx'%id2)