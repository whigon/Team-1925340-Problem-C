# -*- coding: utf-8 -*-
"""
Created on Sat Jan 26 12:22:28 2019

@author: LiYuexiang
"""

import pandas as pd

#Read the data from excel
data = pd.read_excel('F:/2019_MCMProblemC_DATA/2019_MCMProblemC_DATA/MCM_NFLIS_Data.xlsx',sheet_name='Data')
#Change row's index
data = data.set_index('YYYY')

#Read drug data from data as a list
drug = data['SubstanceName'].tolist()
#Dedupilcation
drug = list(set(drug))

#Read county data from data as a list
county_ID = data['FIPS_Combined'].tolist()
#Dedupilcation
county_ID = list(set(county_ID))

row_index = drug
row_index.sort()
#Total is uesed to record the number of a specific opioid use might have started in a county
row_index.append('Total')
col_index = county_ID

#Create a table to record possible counties where a specific opioid use might have started in and the value is started year
startTable = pd.DataFrame(index = row_index, columns = col_index)

#startTable.to_excel('F:/2019_MCMProblemC_DATA/2018_MCMProblemC_DATA/startTable.xlsx')


for d in drug:
    #Filter
    subdata = data[data.SubstanceName == d]
    subdata = subdata.sort_index()
    #A temporary subdata
    tmp = pd.DataFrame()
    
    #Choosable range
    alpha = 0.3
    
    #Find the earliest year
    if 2010 in subdata.index:
        #Select the items in 2010
        tmp = subdata.ix[2010]
        
        '''
        #case1: Olny a row
        if tmp.index.size == 9 and tmp.values.size == 9:
            c = tmp['FIPS_Combined']
            startTable.loc[d, c] = 2010
            
        #case2:2-3rows, we take all of them as possible starting county  
        elif tmp.index.size <=3:
            c = tmp['FIPS_Combined']
            startTable.loc[d, c] = 2010
        '''
        
        #Case1: less 3 counties, all of them are possible
        if (tmp.index.size == 9 and tmp.values.size == 9) or tmp.index.size <=3:
            startTable.loc[d, tmp['FIPS_Combined']] = 2010
        #Case2: more than 3 counties, choose the first 3 counties in a certain range of the maximal number
        else:
            #Get the county which has the maximal DrugReports in this drug
            Max = tmp.max()
            #Get the maximal DrugReports value
            Max_value = Max['DrugReports']
            #Get the certain range of maximal value
            Max_Range = Max_value * (1 - alpha)
            #Select the items which DrugReports is larger than Max_Range
            tmp = tmp[tmp.DrugReports >= Max_Range]
            #Resort the items by descending DrugReports
            tmp = tmp.sort_values('DrugReports', ascending = False)
            #Select the first three rows
            tmp = tmp[0:3]
            #Record those counties
            startTable.loc[d, tmp['FIPS_Combined']] = 2010
            
    
    elif 2011 in subdata.index:
        #Select the items in 2011
        tmp = subdata.ix[2011]
        
        #Case1: less 3 counties, all of them are possible
        if (tmp.index.size == 9 and tmp.values.size == 9) or tmp.index.size <=3:
            startTable.loc[d, tmp['FIPS_Combined']] = 2011
        #Case2: more than 3 counties, choose the first 3 counties in a certain range of the maximal number
        else:
            #Get the county which has the maximal DrugReports in this drug
            Max = tmp.max()
            #Get the maximal DrugReports value
            Max_value = Max['DrugReports']
            #Get the certain range of maximal value
            Max_Range = Max_value * (1 - alpha)
            #Select the items which DrugReports is larger than Max_Range
            tmp = tmp[tmp.DrugReports >= Max_Range]
            #Resort the items by descending DrugReports
            tmp = tmp.sort_values('DrugReports', ascending = False)
            #Select the first three rows
            tmp = tmp[0:3]
            #Record those counties
            startTable.loc[d, tmp['FIPS_Combined']] = 2011
        
    elif 2012 in subdata.index:
        #Select the items in 2012
        tmp = subdata.ix[2012]
        
        #Case1: less 3 counties, all of them are possible
        if (tmp.index.size == 9 and tmp.values.size == 9) or tmp.index.size <=3:
            startTable.loc[d, tmp['FIPS_Combined']] = 2012   
        #Case2: more than 3 counties, choose the first 3 counties in a certain range of the maximal number
        else:
            #Get the county which has the maximal DrugReports in this drug
            Max = tmp.max()
            #Get the maximal DrugReports value
            Max_value = Max['DrugReports']
            #Get the certain range of maximal value
            Max_Range = Max_value * (1 - alpha)
            #Select the items which DrugReports is larger than Max_Range
            tmp = tmp[tmp.DrugReports >= Max_Range]
            #Resort the items by descending DrugReports
            tmp = tmp.sort_values('DrugReports', ascending = False)
            #Select the first three rows
            tmp = tmp[0:3]
            #Record those counties
            startTable.loc[d, tmp['FIPS_Combined']] = 2012
            
    elif 2013 in subdata.index:
        #Select the items in 2013
        tmp = subdata.ix[2013]
        
        #Case1: less 3 counties, all of them are possible
        if (tmp.index.size == 9 and tmp.values.size == 9) or tmp.index.size <=3:
            startTable.loc[d, tmp['FIPS_Combined']] = 2013   
        #Case2: more than 3 counties, choose the first 3 counties in a certain range of the maximal number
        else:
            #Get the county which has the maximal DrugReports in this drug
            Max = tmp.max()
            #Get the maximal DrugReports value
            Max_value = Max['DrugReports']
            #Get the certain range of maximal value
            Max_Range = Max_value * (1 - alpha)
            #Select the items which DrugReports is larger than Max_Range
            tmp = tmp[tmp.DrugReports >= Max_Range]
            #Resort the items by descending DrugReports
            tmp = tmp.sort_values('DrugReports', ascending = False)
            #Select the first three rows
            tmp = tmp[0:3]
            #Record those counties
            startTable.loc[d, tmp['FIPS_Combined']] = 2013
        
    elif 2014 in subdata.index:
        #Select the items in 2014
        tmp = subdata.ix[2014]
        
        #Case1: less 3 counties, all of them are possible
        if (tmp.index.size == 9 and tmp.values.size == 9) or tmp.index.size <=3:
            startTable.loc[d, tmp['FIPS_Combined']] = 2014   
        #Case2: more than 3 counties, choose the first 3 counties in a certain range of the maximal number
        else:
            #Get the county which has the maximal DrugReports in this drug
            Max = tmp.max()
            #Get the maximal DrugReports value
            Max_value = Max['DrugReports']
            #Get the certain range of maximal value
            Max_Range = Max_value * (1 - alpha)
            #Select the items which DrugReports is larger than Max_Range
            tmp = tmp[tmp.DrugReports >= Max_Range]
            #Resort the items by descending DrugReports
            tmp = tmp.sort_values('DrugReports', ascending = False)
            #Select the first three rows
            tmp = tmp[0:3]
            #Record those counties
            startTable.loc[d, tmp['FIPS_Combined']] = 2014
        
    elif 2015 in subdata.index:
        #Select the items in 2015
        tmp = subdata.ix[2015]

        #Case1: less 3 counties, all of them are possible
        if (tmp.index.size == 9 and tmp.values.size == 9) or tmp.index.size <=3:
            startTable.loc[d, tmp['FIPS_Combined']] = 2015   
        #Case2: more than 3 counties, choose the first 3 counties in a certain range of the maximal number
        else:
            #Get the county which has the maximal DrugReports in this drug
            Max = tmp.max()
            #Get the maximal DrugReports value
            Max_value = Max['DrugReports']
            #Get the certain range of maximal value
            Max_Range = Max_value * (1 - alpha)
            #Select the items which DrugReports is larger than Max_Range
            tmp = tmp[tmp.DrugReports >= Max_Range]
            #Resort the items by descending DrugReports
            tmp = tmp.sort_values('DrugReports', ascending = False)
            #Select the first three rows
            tmp = tmp[0:3]
            #Record those counties
            startTable.loc[d, tmp['FIPS_Combined']] = 2015        
            
    elif 2016 in subdata.index:
        #Select the items in 2016
        tmp = subdata.ix[2016]
        
        #Case1: less 3 counties, all of them are possible
        if (tmp.index.size == 9 and tmp.values.size == 9) or tmp.index.size <=3:
            startTable.loc[d, tmp['FIPS_Combined']] = 2016   
        #Case2: more than 3 counties, choose the first 3 counties in a certain range of the maximal number
        else:
            #Get the county which has the maximal DrugReports in this drug
            Max = tmp.max()
            #Get the maximal DrugReports value
            Max_value = Max['DrugReports']
            #Get the certain range of maximal value
            Max_Range = Max_value * (1 - alpha)
            #Select the items which DrugReports is larger than Max_Range
            tmp = tmp[tmp.DrugReports >= Max_Range]
            #Resort the items by descending DrugReports
            tmp = tmp.sort_values('DrugReports', ascending = False)
            #Select the first three rows
            tmp = tmp[0:3]
            #Record those counties
            startTable.loc[d, tmp['FIPS_Combined']] = 2016
        
    elif 2017 in subdata.index:
        #Select the items in 2017
        tmp = subdata.ix[2017]
        
        #Case1: less 3 counties, all of them are possible
        if (tmp.index.size == 9 and tmp.values.size == 9) or tmp.index.size <=3:
            startTable.loc[d, tmp['FIPS_Combined']] = 2017   
        #Case2: more than 3 counties, choose the first 3 counties in a certain range of the maximal number
        else:
            #Get the county which has the maximal DrugReports in this drug
            Max = tmp.max()
            #Get the maximal DrugReports value
            Max_value = Max['DrugReports']
            #Get the certain range of maximal value
            Max_Range = Max_value * (1 - alpha)
            #Select the items which DrugReports is larger than Max_Range
            tmp = tmp[tmp.DrugReports >= Max_Range]
            #Resort the items by descending DrugReports
            tmp = tmp.sort_values('DrugReports', ascending = False)
            #Select the first three rows
            tmp = tmp[0:3]
            #Record those counties
            startTable.loc[d, tmp['FIPS_Combined']] = 2017
        
    #print(tmp.values.size,tmp.index.size)
    

#Calculate the total
for c in county_ID:
    total = startTable[c].count()
    startTable.loc['Total', c] = total

#Store table into excel    
startTable.to_excel('F:/AI/DDD/StartTable-' + '%.1f.xlsx' %alpha)   
       
        
        
  