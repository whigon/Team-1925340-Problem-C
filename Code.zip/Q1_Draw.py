# -*- coding: utf-8 -*-
"""
Created on Sat Jan 26 17:30:46 2019

@author: LiYuexiang
"""

import numpy as np
import pandas as pd
import matplotlib.pyplot as plt


#Read data from StartTable excel, file name need to change to get different  pictures of different alpha
data = pd.read_excel('F:/AI/DDD/StartTable-0.1.xlsx')
#Select the last row
data = data[-1:]

#Remove the items with the number 0
cols=[x for i,x in enumerate(data.columns) if data.iat[0, i] == 0]
series = data.drop(cols,axis=1)
series = series.ix['Total']

State = ('KY', 'OH', 'PA', 'VA', 'WV')

for i in range(0,5):
    if i == 0:
        pre_id = 21
    elif i == 1:
        pre_id = 39
    elif i == 2:
        pre_id = 42
    elif i == 3:
        pre_id = 51
    else:
        pre_id = 54
    
    index_list = []
    for x in series.index:
        tmp = x/1000
        tmp = int(tmp)
        if tmp == pre_id:
            index_list.append(x)
    
    subseries = series[index_list]
    print(subseries)
    #Change figure size
    plt.figure(figsize=(10, 10))
    subseries.plot.bar(title = State[i])
    plt.xlabel('CountyID')
    plt.savefig('pic-0.1-%s.png'%State[i])
    plt.close()
    


#Get numpy array data
series = np.array(data.ix['Total'])
#Finde the max values
max = int(np.max(series))
#Plot pic2
plt.hist(series, bins=max)
#Add title & label
plt.title('alpha = 0.1')
plt.xlabel('The number of opioid that might have been firstly used in a county')
plt.ylabel('Total number')
#Save picture, need to change name
plt.savefig('pic-0.10.png')



