# -*- coding: utf-8 -*-
"""
Created on Sun Jan 27 11:33:46 2019

@author: LiYuexiang
"""

import pandas as pd

GEO_id = []

data1 = pd.read_csv('F:/2019_MCMProblemC_DATA/ACS_10_5YR_DP02_metadata.csv')
data2 = pd.read_csv('F:/2019_MCMProblemC_DATA/ACS_13_5YR_DP02_metadata.csv')

#Select HC01_VCxx from year 2010
bool = data1['GEO.id'].str.contains('HC01')
data1 = data1[bool]
#Get all estimate GEO.id
GEO_id1 = data1['GEO.id'].tolist()

#Select HC01_VCxx from year 2013
bool = data2['GEO.id'].str.contains('HC01')
data2 = data2[bool]
#Get all estimate GEO.id
GEO_id2 = data2['GEO.id'].tolist()

#symmetric difference
diff =list(set(GEO_id2).symmetric_difference(set(GEO_id1)))
print(len(diff))

#intersection
intersec = list(set(GEO_id1).intersection(set(GEO_id2)))
print(len(intersec))


