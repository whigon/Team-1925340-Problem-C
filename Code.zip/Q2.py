# -*- coding: utf-8 -*-
"""
Created on Sun Jan 27 12:32:50 2019

@author: LiYuexiang
"""

import pandas as pd

#The county used to analysis   Note:if you want to analysis other county, you need change it 
id = '0500000US51041'
id2 = '51041'


#item tpye's id
Item_id = []
#Get metadata from excel
data1 = pd.read_csv('F:/2019_MCMProblemC_DATA/ACS_10_5YR_DP02_metadata.csv')
data2 = pd.read_csv('F:/2019_MCMProblemC_DATA/ACS_13_5YR_DP02_metadata.csv')

#Select HC01_VCxx from year 2010
bool = data1['GEO.id'].str.contains('HC01')
data1 = data1[bool]
#Get all estimate item.id
item_id1 = data1['GEO.id'].tolist()

#Select HC01_VCxx from year 2013
bool = data2['GEO.id'].str.contains('HC01')
data2 = data2[bool]
#Get all estimate item.id
item_id2 = data2['GEO.id'].tolist()

#Symmetric_difference
#tmp=list(set(GEO_id2).symmetric_difference(set(GEO_id1)))

#Get intersection item_id list  HC01_VCXXX
Item_id = list(set(item_id1).intersection(set(item_id2)))
Item_id.sort()
#Year = ['2010','2011','2012','2013','2014','2015','2016','2017']

#Create dataframe to store socio-economic data of county
socio_ecoData = pd.DataFrame(index = [], columns = Item_id)

#Get the socio-economic data from each excel and collect them into socio_ecoData
for i in range(0,7):
    #Read data
    data = pd.read_csv('F:/2019_MCMProblemC_DATA/ACS_1%d_5YR_DP02_with_ann.csv'%i)
    #Change index
    data = data.set_index('GEO.id')
    #Read county data with id
    data = data.ix[id]
    #Store the data into socio_ecoData
    for item in Item_id:
        socio_ecoData.loc[2010+i, item] = data[item]
        
#Store the data into excel
socio_ecoData.to_excel('F:/AI/DDD/socio_ecoData_%s.xlsx'%id2)
        

