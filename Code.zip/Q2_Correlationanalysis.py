# -*- coding: utf-8 -*-
"""
Created on Sun Jan 27 19:52:00 2019

@author: LiYuexiang
"""

import pandas as pd

#The county used to analysis   Note:if you want to analysis other county, you need change it
id = '0500000US51041'
id2 = 51041

#Read county's drug data and socio-economic data
drug_data = pd.read_excel('F:/2019_MCMProblemC_DATA/2019_MCMProblemC_DATA/MCM_NFLIS_Data.xlsx',sheet_name='Data')
drug_data = drug_data.set_index('YYYY')
socio_ecodata = pd.read_excel('F:/AI/DDD/socio_ecoData_%s(predicted).xlsx'%id2)

#Define year
Year = [2010,2011,2012,2013,2014,2015,2016,2017]
#Subdrug_data used to collect the total number of opioid drug county reports（Each year has a value)
subdrug_data = pd.Series(index = Year)

for i in range(0,8):
    #Get year's data
    tmp = drug_data.ix[2010+i]
    tmp = tmp.loc[tmp['FIPS_Combined'] == id2]
    t_sum = tmp.sum()
    sum_ = t_sum['DrugReports']
    
    subdrug_data[2010+i] = sum_

#Used to store the pearson correlation between the total number of opioid drug county reports and county's socio-economic data
pearson_correlation = pd.Series(index=socio_ecodata.columns)

#Calculate pearson correlation for each socio-economic item
for c in socio_ecodata.columns:
    sd = socio_ecodata[c]
    #Pearson correlation
    p = sd.corr(subdrug_data)
    #Get absolute value
    p = abs(p)
    #Store
    pearson_correlation[c] = p
    
#Store into excel
pearson_correlation.to_excel('F:/AI/DDD/pearson_correlation_%s.xlsx'%id2)


